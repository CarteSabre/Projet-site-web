CREATE OR REPLACE FUNCTION schema(nomTable VARCHAR) RETURNS SETOF VARCHAR AS $$
DECLARE
-- nomTable VARCHAR := 'emp';
att VARCHAR;
BEGIN
FOR att IN SELECT column_name FROM information_schema.columns
WHERE table_name = nomTable LOOP
RETURN NEXT att;
END LOOP;
RETURN;
END
$$ LANGUAGE plpgsql;
SELECT * from schema('emp');