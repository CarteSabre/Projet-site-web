CREATE OR REPLACE FUNCTION catPlus() RETURNS SETOF tNuplet AS $$
DECLARE
nuplet RECORD;
res tNuplet;
BEGIN
FOR nuplet IN SELECT tablename FROM pg_tables
WHERE tableowner = 'darmont'
LOOP
res.texte := nuplet.tablename;
EXECUTE 'SELECT COUNT(*) FROM ' || nuplet.tablename
INTO res.nombre;
RETURN NEXT res;
END LOOP;
RETURN;
END
$$ LANGUAGE plpgsql;
SELECT * from catPlus();