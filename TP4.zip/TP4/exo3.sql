CREATE TYPE tDeuxAtt AS (
att1 VARCHAR,
att2 VARCHAR
);
CREATE OR REPLACE FUNCTION deuxAtt(nomTable VARCHAR)
RETURNS SETOF tDeuxAtt AS $$
DECLARE
cursDyn REFCURSOR;
att VARCHAR[]; -- Tableau des noms d’attributs
a VARCHAR;
i INT := 1;
res tDeuxAtt;
requete VARCHAR;
BEGIN
-- Récupération des attributs via un curseur paramétré implicite
FOR a IN SELECT column_name FROM information_schema.columns
WHERE table_name = nomTable LIMIT 2 LOOP
att[i] := a;
i := i + 1;
end loop;
-- Construction de la requête
requete := 'SELECT ' || att[1] || ', ' || att[2] || ' FROM '
|| nomTable;
-- Parcours du curseur dynamique
OPEN cursDyn FOR EXECUTE requete;
FETCH cursDyn into res;
WHILE FOUND LOOP
RETURN NEXT res;
FETCH cursDyn into res;
END LOOP;
CLOSE cursDyn;
RETURN;
END
$$ LANGUAGE plpgsql;
SELECT * from deuxAtt('emp');

